import Swipe from "./swipe";

// Creation of element
var mySwipe = new Swipe(document.getElementById('slider'));
