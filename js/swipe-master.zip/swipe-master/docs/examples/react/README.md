React Swipe Example
===================

#### Step to use this example:

+ Install dependencies via `npm install`
+ run `npm start`
+ Open <http://localhost:2992> in browser to see effect!

#### Preview

![Preview](images/preview.png)
